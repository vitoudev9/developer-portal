package com.aunsa.jpa_wrapper;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JpaWrapperApplication {

	public static void main(String[] args) {
		SpringApplication.run(JpaWrapperApplication.class, args);
	}

}
