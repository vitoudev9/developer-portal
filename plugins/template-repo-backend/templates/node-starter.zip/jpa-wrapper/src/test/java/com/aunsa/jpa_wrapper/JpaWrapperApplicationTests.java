package com.aunsa.jpa_wrapper;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JpaWrapperApplicationTests {

	@Test
	void contextLoads() {
	}

}
